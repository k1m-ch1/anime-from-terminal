# TODO

- [x] Write all the api interfaces
  - [x] searching (also continuously fetches until there's no more next page)
  - [x] getting episodes
  - [x] getting servers
  - [x] fetching the stream data
- [x] Figure out a way to query using `iterfzf` correctly
- [x] Figure out all the prompt and the flow of the program
- [] Handle errors
- [] Kinda wanna implement an mcp server for the api too (but that's for another time)
