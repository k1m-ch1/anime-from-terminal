# Requirements

`python` must be installed

Check by running:

```bash
python --version
```

[`mpv`](https://mpv.io/installation/) must be installed

Check by running:

```bash
mpv --version
```

On Linux, `mpv` can be installed using your package manager (or it might already be installed).

On Windows, it's gonna be a bit difficult.

You can try to download `mpv` just from the [offical site](https://mpv.io/installation/).

Here are the steps we used:

1. Went to [https://github.com/shinchiro/mpv-winbuild-cmake/releases](https://github.com/shinchiro/mpv-winbuild-cmake/releases)
2. Extract it to a folder somewhere
3. Add it as an environmental variable following [this tutorial](https://youtu.be/ow2jROvxyH4?si=78CbPF8AE2st7Vtd)
4. Check that it works by doing `mpv --version`, if not, find another tutorial (sorry, Windows kinda sucks for developing)

# Installation

It's very easy to try it out using `uv`.

```bash
uvx --from anime-from-terminal anime
```

And there you go!

Otherwise, simply install it using `pip`

```bash
pip install anime-from-terminal
```

Now run:

```bash
anime
```

# About

This is simply a `cli` front end for the hi-anime scraping API by @f4rh4d-4hmed [this is their repo](https://github.com/f4rh4d-4hmed/HiAnime-Api).

# TODO

- [x] Write all the api interfaces
  - [x] searching (also continuously fetches until there's no more next page)
  - [x] getting episodes
  - [x] getting servers
  - [x] fetching the stream data
- [x] Figure out a way to query using `iterfzf` correctly
- [x] Figure out all the prompt and the flow of the program
- [] Handle errors
- [] Kinda wanna implement an mcp server for the api too (but that's for another time)
